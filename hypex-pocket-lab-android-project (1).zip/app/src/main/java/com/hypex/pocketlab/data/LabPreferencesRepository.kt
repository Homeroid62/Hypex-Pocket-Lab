package com.hypex.pocketlab.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hypex_pocket_lab_prefs")

data class LabData(
    val counter: Int = 0,
    val note: String = ""
)

class LabPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val COUNTER = intPreferencesKey("lab_counter")
        val NOTE = stringPreferencesKey("lab_note")
    }

    val labDataFlow: Flow<LabData> = context.dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }
        .map { preferences ->
            val counter = preferences[PreferencesKeys.COUNTER] ?: 0
            val note = preferences[PreferencesKeys.NOTE] ?: ""
            LabData(counter = counter, note = note)
        }

    suspend fun updateCounter(newCounter: Int) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.COUNTER] = newCounter
        }
    }

    suspend fun saveNote(newNote: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.NOTE] = newNote
        }
    }

    suspend fun resetCounter() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.COUNTER] = 0
        }
    }
}