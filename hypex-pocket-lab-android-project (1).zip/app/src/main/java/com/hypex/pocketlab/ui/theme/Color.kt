package com.hypex.pocketlab.ui.theme

import androidx.compose.ui.graphics.Color

val BrandBlue = Color(0xFF005AC1)
val BrandBlueContainer = Color(0xFFD8E2FF)
val OnBrandBlue = Color(0xFFFFFFFF)
val OnBrandBlueContainer = Color(0xFF001A41)

val SurfaceLight = Color(0xFFFDFBFF)
val OnSurfaceLight = Color(0xFF1A1C1E)
val OutlineLight = Color(0xFF73777F)
val SurfaceVariantLight = Color(0xFFE0E2EC)

val ErrorRed = Color(0xFFBA1A1A)
val SuccessGreen = Color(0xFF1E824C)