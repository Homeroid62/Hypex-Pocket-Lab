package com.hypex.pocketlab.ui

sealed interface PocketLabUiState {
    object Loading : PocketLabUiState
    data class Success(
        val counter: Int,
        val savedNote: String,
        val isSaving: Boolean = false,
        val userFeedbackMessage: String? = null
    ) : PocketLabUiState
    data class Error(val message: String) : PocketLabUiState
}