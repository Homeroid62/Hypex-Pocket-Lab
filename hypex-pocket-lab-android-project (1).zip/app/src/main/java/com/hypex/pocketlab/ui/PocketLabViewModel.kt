package com.hypex.pocketlab.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.hypex.pocketlab.data.LabPreferencesRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class PocketLabViewModel(
    private val repository: LabPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<PocketLabUiState>(PocketLabUiState.Loading)
    val uiState: StateFlow<PocketLabUiState> = _uiState.asStateFlow()

    init {
        observeLabData()
    }

    private fun observeLabData() {
        viewModelScope.launch {
            repository.labDataFlow
                .catch { exception ->
                    _uiState.value = PocketLabUiState.Error(
                        message = exception.localizedMessage ?: "Failed to read saved data"
                    )
                }
                .collect { data ->
                    val currentState = _uiState.value
                    if (currentState is PocketLabUiState.Success) {
                        _uiState.value = currentState.copy(
                            counter = data.counter,
                            savedNote = data.note
                        )
                    } else {
                        _uiState.value = PocketLabUiState.Success(
                            counter = data.counter,
                            savedNote = data.note
                        )
                    }
                }
        }
    }

    fun incrementCounter() {
        val currentState = _uiState.value as? PocketLabUiState.Success ?: return
        val nextValue = currentState.counter + 1
        viewModelScope.launch {
            try {
                repository.updateCounter(nextValue)
                _uiState.value = currentState.copy(
                    counter = nextValue,
                    userFeedbackMessage = "Counter updated to $nextValue"
                )
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    userFeedbackMessage = "Failed to update counter: ${e.localizedMessage}"
                )
            }
        }
    }

    fun resetCounter() {
        val currentState = _uiState.value as? PocketLabUiState.Success ?: return
        viewModelScope.launch {
            try {
                repository.resetCounter()
                _uiState.value = currentState.copy(
                    counter = 0,
                    userFeedbackMessage = "Counter reset to 0"
                )
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    userFeedbackMessage = "Failed to reset counter: ${e.localizedMessage}"
                )
            }
        }
    }

    fun saveNote(note: String) {
        val currentState = _uiState.value as? PocketLabUiState.Success ?: return
        val trimmed = note.trim()
        if (trimmed.isEmpty()) {
            _uiState.value = currentState.copy(
                userFeedbackMessage = "Note cannot be empty"
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = currentState.copy(isSaving = true)
            try {
                repository.saveNote(trimmed)
                _uiState.value = currentState.copy(
                    savedNote = trimmed,
                    isSaving = false,
                    userFeedbackMessage = "Note saved successfully"
                )
            } catch (e: Exception) {
                _uiState.value = currentState.copy(
                    isSaving = false,
                    userFeedbackMessage = "Failed to save note: ${e.localizedMessage}"
                )
            }
        }
    }

    fun clearFeedbackMessage() {
        val currentState = _uiState.value as? PocketLabUiState.Success ?: return
        _uiState.value = currentState.copy(userFeedbackMessage = null)
    }

    companion object {
        fun provideFactory(repository: LabPreferencesRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return PocketLabViewModel(repository) as T
                }
            }
    }
}