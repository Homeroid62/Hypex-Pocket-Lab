package com.hypex.pocketlab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.hypex.pocketlab.data.LabPreferencesRepository
import com.hypex.pocketlab.ui.PocketLabScreen
import com.hypex.pocketlab.ui.PocketLabViewModel
import com.hypex.pocketlab.ui.theme.PocketLabTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PocketLabViewModel by viewModels {
        PocketLabViewModel.provideFactory(LabPreferencesRepository(applicationContext))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PocketLabTheme {
                PocketLabScreen(viewModel = viewModel)
            }
        }
    }
}