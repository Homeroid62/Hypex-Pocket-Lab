package com.hypex.pocketlab

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PocketLabLogicTest {

    @Test
    fun testCounterInitialValue() {
        val initialCounter = 0
        assertEquals(0, initialCounter)
    }

    @Test
    fun testCounterIncrement() {
        var counter = 0
        counter += 1
        assertEquals(1, counter)
        counter += 1
        assertEquals(2, counter)
    }

    @Test
    fun testCounterReset() {
        var counter = 42
        counter = 0
        assertEquals(0, counter)
    }

    @Test
    fun testNoteValidation() {
        val validNote = "Battery temperature nominal"
        val emptyNote = "   "

        assertTrue(validNote.isNotBlank())
        assertTrue(emptyNote.trim().isEmpty())
    }
}