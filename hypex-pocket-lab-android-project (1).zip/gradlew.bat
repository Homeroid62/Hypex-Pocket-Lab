@rem Gradle wrapper
gradle %*
