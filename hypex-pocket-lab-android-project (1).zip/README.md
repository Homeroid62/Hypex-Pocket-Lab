# HYPEX Pocket Lab (Native Android)

A small, reliable, offline-first native Android application built with Kotlin, Jetpack Compose, Material 3, and AndroidX DataStore Preferences. Optimized for Android 15 and low-memory Android Go devices.

## Requirements
- Android SDK 35 (minSdk 24, targetSdk 35)
- Java Development Kit (JDK) 17
- Gradle 8.7+

## Quick Build Commands
```bash
# Run unit tests
./gradlew testDebugUnitTest

# Build debug APK
./gradlew assembleDebug
# Generated at: app/build/outputs/apk/debug/app-debug.apk

# Install directly to attached phone
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Free Cloud Build (No Android Studio required)
1. Push this folder to a GitHub repository.
2. Go to the **Actions** tab.
3. Once the workflow completes (2-3 minutes), download the `hypex-pocket-lab-debug-apk` artifact!
